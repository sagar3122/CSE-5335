<?php
class queries extends CI_Model{
  function form_individual($data){
    //Insert in table users_all the individual user
    $Email = $this->input->post('email');
    $Password = $this->input->post('password');
    $Last_Name = $this->input->post('lname');
    $First_Name = $this->input->post('fname');
    $address = $this->input->post('address');
    $city = $this->input->post('city');
    $state = $this->input->post('select');
    $postal_code = $this->input->post('ZipCode');


    // 'U_Email' => $this->input->post('email'),
    // 'U_Password' => $this->input->post('password'),
    // 'U_Last_Name' => $this->input->post('fname'),
    // 'U_First_Name' => $this->input->post('lname'),
    // 'U_address' => $this->input->post('address'),
    // 'U_city' => $this->input->post('city'),
    // 'U_state' => $this->input->post('select'),
    // 'U_postal_code' => $this->input->post('ZipCode'));

    $z = $this->db->where(['U_Email'=>$Email]) -> get('users');
    if($z->num_rows() == 0){
		$this->db->query("INSERT into users(U_Email,U_Password,U_Last_Name,U_First_Name,U_address,U_city,U_state,U_postal_code,U_role_ID)
            VALUES ('$Email','$Password','$Last_Name','$First_Name','$address','$city','$state','$postal_code','1')");
            $this->session->set_flashdata('success','Registered');
    }

    else{
                $this->session->set_flashdata('error','User already exists');
                // $this->load->view('pages/individual');
                // $this->session->sess_destroy();

        }
    // $this->db->insert('users',$data);
    // $this->db->_insert();
}

function form_business($data){
  //Insert in table users_all the individual user
  $Email = $this->input->post('email');
  $Password = $this->input->post('password');
  $Last_Name = $this->input->post('lname');
  $First_Name = $this->input->post('fname');
  $address = $this->input->post('address');
  $city = $this->input->post('city');
  $state = $this->input->post('select');
  $postal_code = $this->input->post('ZipCode');
  $business = $this->input->post('business');


  // 'U_Email' => $this->input->post('email'),
  // 'U_Password' => $this->input->post('password'),
  // 'U_Last_Name' => $this->input->post('fname'),
  // 'U_First_Name' => $this->input->post('lname'),
  // 'U_address' => $this->input->post('address'),
  // 'U_city' => $this->input->post('city'),
  // 'U_state' => $this->input->post('select'),
  // 'U_postal_code' => $this->input->post('ZipCode'));
  // 'U_type_of_business' => $this->input->post('business'));

  $z = $this->db->where(['U_Email'=>$Email]) -> get('users');
  if($z->num_rows() == 0){
  $this->db->query("INSERT into users(U_Email,U_Password,U_Last_Name,U_First_Name,U_address,U_city,U_state,U_postal_code,U_type_of_business,U_role_ID)
          VALUES ('$Email','$Password','$Last_Name','$First_Name','$address','$city','$state','$postal_code','$business','2')");
          $this->session->set_flashdata('success','Registered');
  }

  else{
              $this->session->set_flashdata('error','User already exists');
              // $this->load->view('pages/individual');
              // $this->session->sess_destroy();

      }
  // $this->db->insert('users',$data);
  // $this->db->_insert();
}
function form_agentlean($data){
  //Insert in table users_all the individual user
  $Email = $this->input->post('email');
  $Password = $this->input->post('password');
  $Last_Name = $this->input->post('lname');
  $First_Name = $this->input->post('fname');
  $address = $this->input->post('address');
  $city = $this->input->post('city');
  $state = $this->input->post('select');
  $postal_code = $this->input->post('ZipCode');


  // 'U_Email' => $this->input->post('email'),
  // 'U_Password' => $this->input->post('password'),
  // 'U_Last_Name' => $this->input->post('fname'),
  // 'U_First_Name' => $this->input->post('lname'),
  // 'U_address' => $this->input->post('address'),
  // 'U_city' => $this->input->post('city'),
  // 'U_state' => $this->input->post('select'),
  // 'U_postal_code' => $this->input->post('ZipCode'));

  $z = $this->db->where(['U_Email'=>$Email]) -> get('users');
  if($z->num_rows() == 0){
  $this->db->query("INSERT into users(U_Email,U_Password,U_Last_Name,U_First_Name,U_address,U_city,U_state,U_postal_code,U_role_ID)
          VALUES ('$Email','$Password','$Last_Name','$First_Name','$address','$city','$state','$postal_code','3')");
          $this->session->set_flashdata('success','Registered');
  }

  else{
              $this->session->set_flashdata('error','User already exists');
              // $this->load->view('pages/individual');
              // $this->session->sess_destroy();

      }
  // $this->db->insert('users',$data);
  // $this->db->_insert();
}

function form_login($data){

      $email = $this -> input->post('email');
      $password = $this -> input->post('password');
    	$query= $this->db ->where(['U_Email'=>$email, 'U_Password'=>$password])->get('users');
    	  if ($query->num_rows() >0)
    	  {
    	                    		//return $query->row();
          $a=$this -> db ->query ("select * from users where U_Email='$email' and U_Password='$password' and U_role_ID ='1'");
          $b=$this -> db ->query ("select * from users where U_Email='$email' and U_Password='$password' and U_role_ID ='2'");
          $c=$this -> db ->query ("select * from users where U_Email='$email' and U_Password='$password' and U_role_ID ='3'");
    	    if ($a->num_rows() >0){
            $this->session->set_flashdata('success','Login successful');
            $this->session->set_flashdata('email',$email);
            redirect('indi_controller/home');
            // return $this->load->view('indi_controller/home',$data);
                 }
    	     else if($b -> num_rows() >0) {
             $this->session->set_flashdata('success','Login successful');
                $this->session->set_flashdata('email',$email);
                    redirect('business_controller/home');
                  // return $this->load->view('pages/HomeBusiness',$email);
                    }
            else if($c -> num_rows() >0){
              $this->session->set_flashdata('success','Login successful');
                  $this->session->set_flashdata('email',$email);
                  redirect('agent_controller/home');
                  // return $this->load->view('pages/ListEvents',$email);
                    }
                    }
              // $this->session->set_flashdata('success','Login successful');
            else{
            $this->session->set_flashdata('error','Username or password are incorrect');
            redirect('/login/view');
                        }
    	            }

function fetch_indi_business($data)
          {
          // print_r($data);
          // echo $data['email'];
          $query= $this->db ->where(['U_Email'=>$data['email']])->get('events');
          $result = $query->result();
          // print_r($result);
          return $result;
          }

function fetch_buyfromus($data)
          {
            // print_r($data);
            // echo $data['email'];
            $query= $this->db->query("SELECT Product_Description, Product_Price FROM buy_from_us");
            // echo $query;
            $result = $query->result();
            // print_r($result);
            return $result;
            }

function fetch_agent_event($data)
                      {
                        // print_r($data);
                        // echo $data['email'];
                        $query= $this->db->query("select * from events");
                        // echo $query;
                        $result = $query->result();
                        // print_r($result);
                        return $result;
                        }
function edit_agent_event($data)
            {
              // 'edit' => $this->input->post('edit'),
              $name = $this->input->post('name');
              $responsible = $this->input->post('responsible');
              $place = $this->input->post('place');
              $hour = $this->input->post('hour');
              $price = $this->input->post('price');
              $date = $this->input->post('date');
              // print_r($data);
              // echo $data['email'];
              // $query= $this->db ->where(['E_ID'=>$data['edit']])->get('events');
              $query= $this->db->query("UPDATE events SET E_Name='$name',E_place='$place',E_date='$date',E_ticket_value=$price,E_hour='$hour',E_Responsible='$responsible'
                    WHERE E_ID = '$data[edit]'");

              $this->session->set_flashdata('success','Updated');
              // echo $query;
              // $result = $query->result();
              // print_r($result);
              // return $result;
            }
function delete_agent_event($data){
              $query= $this->db->query("DELETE FROM events WHERE E_ID = '$data[delete]'");



}

function add_agent_event($data)
            {
              // 'edit' => $this->input->post('edit'),
              $name = $this->input->post('name');
              $responsible = $this->input->post('responsible');
              $place = $this->input->post('place');
              $hour = $this->input->post('hour');
              $price = $this->input->post('price');
              $date = $this->input->post('date');
              // print_r($data);
              // echo $data['email'];
              // $query= $this->db ->where(['E_ID'=>$data['edit']])->get('events');
              $query= $this->db->query("INSERT INTO events(E_Name, E_place, E_date, E_ticket_value, E_hour, E_Responsible)
                VALUES('$name','$place','$date','$price','$hour','$responsible')");

              $this->session->set_flashdata('success','Inserted');
              // echo $query;
              // $result = $query->result();
              // print_r($result);
              // return $result;
            }

  function fetch_agent_profile($data)
                      {
                      // print_r($data);
                      // echo $data['email'];
                      $query= $this->db ->where(['U_Email'=>$data['email']])->get('users');
                      $result = $query->result();
                      // print_r($result);
                      return $result;
                      }

  function fetch_indi_profile($data)
                                          {
                                          // print_r($data);
                                          // echo $data['email'];
                                          $query= $this->db ->where(['U_Email'=>$data['email']])->get('users');
                                          $result = $query->result();
                                          // print_r($result);
                                          return $result;
                                          }

function edit_agent_profile($data)
                                  {
                                    // 'edit' => $this->input->post('edit'),
                                    $fname = $this->input->post('fname');
                                    $rname = $this->input->post('rname');
                                    $email = $this->input->post('email');
                                    $phone = $this->input->post('phone');
                                    $username = $this->input->post('username');
                                    $password = $this->input->post('password');
                                    // print_r($data);
                                    // echo $data['email'];
                                    // $query= $this->db ->where(['E_ID'=>$data['edit']])->get('events');
                                    $query= $this->db->query("UPDATE users SET U_Email = '$email', U_Password = '$password', U_First_Name = '$fname', U_Username = '$username', U_Phone = '$phone', U_Reg_Name = '$rname' WHERE U_Email = '$data[email]'");

                                    $this->session->set_flashdata('success','Updated');
                                    // echo $query;
                                    // $result = $query->result();
                                    // print_r($result);
                                    // return $result;
                                  }

function edit_indi_profile($data)
{
    // 'edit' => $this->input->post('edit'),
    $fname = $this->input->post('fname');
    $lname = $this->input->post('lname');
    $email = $this->input->post('email');
    $phone = $this->input->post('phone');
    $username = $this->input->post('username');
    $password = $this->input->post('password');
    // print_r($data);
    // echo $data['email'];
    // $query= $this->db ->where(['E_ID'=>$data['edit']])->get('events');
    $query= $this->db->query("UPDATE users SET U_Email = '$email', U_Password = '$password', U_First_Name = '$fname', U_Username = '$username', U_Phone = '$phone', U_Last_Name = '$lname' WHERE U_Email = '$data[email]'");

    $this->session->set_flashdata('success','Updated');
    // echo $query;
    // $result = $query->result();
    // print_r($result);
    // return $result;
  }

  function edit_business_profile($data)
  {
      // 'edit' => $this->input->post('edit'),
      $fname = $this->input->post('fname');
      $foundname = $this->input->post('foundname');
      $email = $this->input->post('email');
      $phone = $this->input->post('phone');
      $username = $this->input->post('username');
      $password = $this->input->post('password');
      // print_r($data);
      // echo $data['email'];
      // $query= $this->db ->where(['E_ID'=>$data['edit']])->get('events');
      $query= $this->db->query("UPDATE users SET U_Email = '$email', U_Password = '$password', U_First_Name = '$fname', U_Username = '$username', U_Phone = '$phone', U_Foundation_Name = '$foundname' WHERE U_Email = '$data[email]'");

      $this->session->set_flashdata('success','Updated');
      // echo $query;
      // $result = $query->result();
      // print_r($result);
      // return $result;
    }

  function form_contact($data){
    //Insert in table users_all the individual user
    $email = $this->input->post('email');
    $lname = $this->input->post('lname');
    $fname = $this->input->post('fname');
    $topic = $this->input->post('topic');
    $message = $this->input->post('message');


    // 'U_Email' => $this->input->post('email'),
    // 'U_Password' => $this->input->post('password'),
    // 'U_Last_Name' => $this->input->post('fname'),
    // 'U_First_Name' => $this->input->post('lname'),
    // 'U_address' => $this->input->post('address'),
    // 'U_city' => $this->input->post('city'),
    // 'U_state' => $this->input->post('select'),
    // 'U_postal_code' => $this->input->post('ZipCode'));

    // $z = $this->db->where(['U_Email'=>$Email]) -> get('users');
    // if($z->num_rows() == 0){
		$this->db->query("INSERT INTO contact_us(First_name,Last_name,Email_ID,Contact_Topic,Contact_Message) VALUES ('$fname','$lname','$email','$topic','$message')");
    $this->session->set_flashdata('success','Inserted');
    // }

    // else{
    //             $this->session->set_flashdata('error','User already exists');
                // $this->load->view('pages/individual');
                // $this->session->sess_destroy();

        // }
    // $this->db->insert('users',$data);
    // $this->db->_insert();
}
function buyfromus2_insert($data)
{
  $email = $this->input->post('email');
  $product_description = $this->input->post('pd');
  $product_price = $this->input->post('pp');
  $quant = $this->input->post('quant');
  $query = $this->db->query("INSERT INTO buy_from_us_order(Product_Description, Product_Price, Order_quantity, User_Email)
               VALUES('$product_description','$product_price','$quant','$email')");
  echo $query;
  $this->session->set_flashdata('success','Your order is placed');
}

function fetch_business_profile($data)
                                        {
                                        // print_r($data);
                                        // echo $data['email'];
                                        $query= $this->db ->where(['U_Email'=>$data['email']])->get('users');
                                        $result = $query->result();
                                        // print_r($result);
                                        return $result;
                                        }




} ?>
