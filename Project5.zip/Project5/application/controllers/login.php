<?php
class login extends CI_Controller{
	public function view($page = 'login'){
		if (!file_exists(APPPATH.'views/pages/'.$page.'.php')){
			show_404();
		}
		// $data['title'] = ucfirst($page);
    $this->load->view('pages/header_view1');
		$this->load->view('pages/'.$page);
    $this->load->view('pages/footer_view');
}
}
?>
