<?php

class validate_ctrl extends CI_Controller {

    function __construct() {
        parent::__construct();
//
   // $this->load->helper('form');
  }

    function individual()
	{
		// $this->load->library('form_validation');

    $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

		$this->form_validation->set_rules('email', 'Email',  'required|valid_email');
    $this->form_validation->set_rules('fname', 'first name',  'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('password', 'Password',  'required|regex_match[/^[a-zA-Z]\w{8,16}$/]');
    $this->form_validation->set_rules('lname', 'last name', 'required|regex_match[/^([A-Za-z ]+)$/]');
		$this->form_validation->set_rules('address', 'Address', 'required');
    $this->form_validation->set_rules('city', 'City', 'required');
    $this->form_validation->set_rules('select', 'State', 'required');
    $this->form_validation->set_rules('ZipCode', 'ZipCode', 'required|regex_match[/^\d{5}$/]');

		if ($this->form_validation->run() == FALSE)
		{
      $this->session->set_flashdata('error','There is an error, please check your input');
      $this->load->view('pages/individual');
      $this->session->sess_destroy();

		}
		else
		{
      $this->load->model('queries');
      // $roleID = '1';
      $data = array(
      // 'U_Email' => $this->input->post('email'),
      // 'U_Password' => $this->input->post('password'),
      // 'U_Last_Name' => $this->input->post('fname'),
      // 'U_First_Name' => $this->input->post('lname'),
      // 'U_address' => $this->input->post('address'),
      // 'U_city' => $this->input->post('city'),
      // 'U_state' => $this->input->post('select'),
      // 'U_postal_code' => $this->input->post('ZipCode')
    );
      // 'U_role_ID' => $this->input->post('1'));
      //Transfering data to Model
      $this->queries->form_individual($data);
      // $data['message'] = 'Data Inserted Successfully';
      //Loading View

      $this->load->view('pages/individual');
			$this->session->sess_destroy();
		}
	}

  function business()
{
  // $this->load->library('form_validation');

  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

  $this->form_validation->set_rules('email', 'Email',  'required|valid_email');
  $this->form_validation->set_rules('fname', 'first name',  'required|regex_match[/^([A-Za-z ]+)$/]');
  $this->form_validation->set_rules('password', 'Password',  'required|regex_match[/^[a-zA-Z]\w{8,16}$/]');
  $this->form_validation->set_rules('lname', 'last name', 'required|regex_match[/^([A-Za-z ]+)$/]');
  $this->form_validation->set_rules('address', 'Address', 'required');
  $this->form_validation->set_rules('city', 'City', 'required');
  $this->form_validation->set_rules('select', 'State', 'required');
  $this->form_validation->set_rules('ZipCode', 'ZipCode', 'required|regex_match[/^\d{5}$/]');
  $this->form_validation->set_rules('business', 'Business', 'required');


  if ($this->form_validation->run() == FALSE)
  {
    $this->session->set_flashdata('error','There is an error, please check your input');
    $this->load->view('pages/business');
    $this->session->sess_destroy();

  }
  else
  {
    $this->load->model('queries');
    // $roleID = '1';
    $data = array(
    // 'U_Email' => $this->input->post('email'),
    // 'U_Password' => $this->input->post('password'),
    // 'U_Last_Name' => $this->input->post('fname'),
    // 'U_First_Name' => $this->input->post('lname'),
    // 'U_address' => $this->input->post('address'),
    // 'U_city' => $this->input->post('city'),
    // 'U_state' => $this->input->post('select'),
    // 'U_postal_code' => $this->input->post('ZipCode'),
    // 'U_type_of_business' => $this->input->post('business')
  );
    // 'U_role_ID' => $this->input->post('1'));
    //Transfering data to Model
    $this->queries->form_business($data);
    // $data['message'] = 'Data Inserted Successfully';
    //Loading View

    $this->load->view('pages/business');
    $this->session->sess_destroy();
  }
}

function agentlean()
{
// $this->load->library('form_validation');

$this->form_validation->set_error_delimiters('<div class="error">', '</div>');

$this->form_validation->set_rules('email', 'Email',  'required|valid_email');
$this->form_validation->set_rules('fname', 'first name',  'required|regex_match[/^([A-Za-z ]+)$/]');
$this->form_validation->set_rules('password', 'Password',  'required|regex_match[/^[a-zA-Z]\w{8,16}$/]');
$this->form_validation->set_rules('lname', 'last name', 'required|regex_match[/^([A-Za-z ]+)$/]');
$this->form_validation->set_rules('address', 'Address', 'required');
$this->form_validation->set_rules('city', 'City', 'required');
$this->form_validation->set_rules('select', 'State', 'required');
$this->form_validation->set_rules('ZipCode', 'ZipCode', 'required|regex_match[/^\d{5}$/]');

if ($this->form_validation->run() == FALSE)
{
  $this->session->set_flashdata('error','There is an error, please check your input');
  $this->load->view('pages/agentlean');
  $this->session->sess_destroy();

}
else
{
  $this->load->model('queries');
  // $roleID = '1';
  $data = array(
  // 'U_Email' => $this->input->post('email'),
  // 'U_Password' => $this->input->post('password'),
  // 'U_Last_Name' => $this->input->post('fname'),
  // 'U_First_Name' => $this->input->post('lname'),
  // 'U_address' => $this->input->post('address'),
  // 'U_city' => $this->input->post('city'),
  // 'U_state' => $this->input->post('select'),
  // 'U_postal_code' => $this->input->post('ZipCode')
);
  // 'U_role_ID' => $this->input->post('1'));
  //Transfering data to Model
  $this->queries->form_agentlean($data);
  // $data['message'] = 'Data Inserted Successfully';
  //Loading View

  $this->load->view('pages/agentlean');
  $this->session->sess_destroy();
}
}


function login(){
	  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'required|regex_match[/^[a-zA-Z]\w{8,16}$/]');


		if ($this->form_validation->run() == TRUE)
		{
			$this->load->model('queries');
			$data = $this->input->post();
      // print_r($data);
			// unset($data['submit']);
      // print_r($data);
			$data=array("email" => $this->input->post("email"),"password" => $this->input->post("password"));
			// //"password" => $this->input->post("password"));
			$this->queries->form_login($data);
			$this->session->sess_destroy();
			}
			else
				{
				$this->session->set_flashdata('error','Please check your credentials');
        redirect('/login/view');
        // require('login.php');
        // $login = new login();
        // $login->view();

				$this->session->sess_destroy();
				}

}


function agent_button_edit(){
	  // $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

		// $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		// $this->form_validation->set_rules('password', 'Password', 'required|regex_match[/^[a-zA-Z]\w{8,16}$/]');


		// if ($this->form_validation->run() == TRUE)
		// {
		$this->load->model('queries');
		$data = $this->input->post();
    $this->session->set_flashdata('eventid',$data);
    // redirect('/agent_controller/edit');
    $this->load->view('pages/EditEvent');
    // print_r($data);
		// unset($data['submit']);
      // print_r($data);
			// $data=array("email" => $this->input->post("email"),"password" => $this->input->post("password"));
			// // //"password" => $this->input->post("password"));
			// $this->queries->form_login($data);
			// $this->session->sess_destroy();
			// }
			// else
			// 	{
			// 	$this->session->set_flashdata('error','Please check your credentials');
      //   redirect('/login/view');
      //   // require('login.php');
      //   // $login = new login();
      //   // $login->view();
      //
			// 	$this->session->sess_destroy();
			// 	}

}

function agent_event_edit(){
	  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
    $this->form_validation->set_rules('name', 'Name',  'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('responsible', 'Responsible', 'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('place', 'Place', 'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('hour', 'Hour', 'required');
    $this->form_validation->set_rules('price', 'Price', 'required');
    $this->form_validation->set_rules('date', 'Date', 'required');

    if ($this->form_validation->run() == FALSE)
    {
      $data['edit'] = $this->input->post('edit');
      $this->session->set_flashdata('error','There is an error, please check your input');
      $this->session->set_flashdata('eventid',$data);
      // $this->edit();
      // redirect('/agent_controller/edit');

      $this->load->view('pages/EditEvent');
      // $this->session->sess_destroy();

    }
    else
    {
      $this->load->model('queries');
      // $roleID = '1';
      $data = array(
      'edit' => $this->input->post('edit'),
      // 'E_Name' => $this->input->post('name'),
      // 'E_Responsible' => $this->input->post('responsible'),
      // 'E_place' => $this->input->post('place'),
      // 'E_hour' => $this->input->post('hour'),
      // 'E_ticket_value' => $this->input->post('price'),
      // 'E_date' => $this->input->post('date')
    );
      // 'U_role_ID' => $this->input->post('1'));
      //Transfering data to Model
      $this->queries->edit_agent_event($data);
      // $data['message'] = 'Data Inserted Successfully';
      //Loading View

      $this->load->view('pages/EditEvent');
      // $this->session->sess_destroy();
    }

}

function agent_button_delete(){
	  // $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

		// $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		// $this->form_validation->set_rules('password', 'Password', 'required|regex_match[/^[a-zA-Z]\w{8,16}$/]');


		// if ($this->form_validation->run() == TRUE)
		// {
		$this->load->model('queries');
		$data = $this->input->post();
    // $this->session->set_flashdata('eventid',$data);
    // echo $data['delete'];
    $this->queries->delete_agent_event($data);
    redirect('/agent_controller/home');
    // $this->load->view('pages/ListEvents');

}
function agent_button_add(){
	  // $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

		// $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		// $this->form_validation->set_rules('password', 'Password', 'required|regex_match[/^[a-zA-Z]\w{8,16}$/]');


		// if ($this->form_validation->run() == TRUE)
		// {
		$this->load->model('queries');
		$data = $this->input->post();
    // print_r($data);
    $this->session->set_flashdata('email',$data['email']);
    // echo $data['delete'];
    // $this->queries->delete_agent_event($data);
    // redirect('/agent_controller/home');
    $this->load->view('pages/AddEvent');

}

function agent_event_add(){
	  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
    $this->form_validation->set_rules('name', 'Name',  'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('responsible', 'Responsible', 'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('place', 'Place', 'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('hour', 'Hour', 'required');
    $this->form_validation->set_rules('price', 'Price', 'required');
    $this->form_validation->set_rules('date', 'Date', 'required');

    if ($this->form_validation->run() == FALSE)
    {
      $data['email'] = $this->input->post('email');
      $this->session->set_flashdata('error','There is an error, please check your input');
      $this->session->set_flashdata('email',$data['email']);
      // $this->edit();
      // redirect('/agent_controller/edit');

      $this->load->view('pages/AddEvent');
      $this->session->sess_destroy();

    }
    else
    {
      $this->load->model('queries');
      // $roleID = '1';
      $data = array(
      'email' => $this->input->post('email'),
      // 'E_Name' => $this->input->post('name'),
      // 'E_Responsible' => $this->input->post('responsible'),
      // 'E_place' => $this->input->post('place'),
      // 'E_hour' => $this->input->post('hour'),
      // 'E_ticket_value' => $this->input->post('price'),
      // 'E_date' => $this->input->post('date')
    );
      // 'U_role_ID' => $this->input->post('1'));
      //Transfering data to Model
      $this->session->set_flashdata('email',$data['email']);
      $this->queries->add_agent_event($data);
      // $data['message'] = 'Data Inserted Successfully';
      //Loading View

      $this->load->view('pages/AddEvent');
      $this->session->sess_destroy();
    }

}

function agent_profile(){
	  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
    $this->form_validation->set_rules('fname', 'First Name',  'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('rname', 'Registration Name', 'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
    $this->form_validation->set_rules('phone', 'Phone', 'required|regex_match[/^(\(?\s*\d{3}\s*[\)–\.]?\s*)?[2-9]\d{2}\s*[–\.]\s*\d{4}$/]');
    $this->form_validation->set_rules('username', 'Username', 'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('password', 'Password', 'required|regex_match[/^[a-zA-Z]\w{8,16}$/]');

    if ($this->form_validation->run() == FALSE)
    {
      $data['email'] = $this->input->post('email');
      $this->load->model('queries');
      $data['result'] = $this->queries->fetch_agent_profile($data);
      $this->session->set_flashdata('error','There is an error, please check your input');
      // $this->session->set_flashdata('email',$data);
      // $this->edit();
      // redirect('/agent_controller/edit');

      $this->load->view('pages/ProfileAgentSubMenu',$data);
      $this->session->sess_destroy();

    }
    else
    {
      $this->load->model('queries');
      // $roleID = '1';
      $data = array(
      'email' => $this->input->post('email'),
      // 'E_Name' => $this->input->post('name'),
      // 'E_Responsible' => $this->input->post('responsible'),
      // 'E_place' => $this->input->post('place'),
      // 'E_hour' => $this->input->post('hour'),
      // 'E_ticket_value' => $this->input->post('price'),
      // 'E_date' => $this->input->post('date')
    );
      // 'U_role_ID' => $this->input->post('1'));
      //Transfering data to Model
      $this->queries->edit_agent_profile($data);
      // $data['message'] = 'Data Inserted Successfully';
      //Loading View
      $data['email'] = $this->input->post('email');
      $this->load->model('queries');
      $data['result'] = $this->queries->fetch_agent_profile($data);

      $this->load->view('pages/ProfileAgentSubMenu',$data);
      $this->session->sess_destroy();
    }

}

function indi_profile(){
	  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
    $this->form_validation->set_rules('fname', 'First Name',  'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('lname', 'Last Name', 'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
    $this->form_validation->set_rules('phone', 'Phone', 'required|regex_match[/^(\(?\s*\d{3}\s*[\)–\.]?\s*)?[2-9]\d{2}\s*[–\.]\s*\d{4}$/]');
    $this->form_validation->set_rules('username', 'Username', 'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('password', 'Password', 'required|regex_match[/^[a-zA-Z]\w{8,16}$/]');

    if ($this->form_validation->run() == FALSE)
    {
      $data['email'] = $this->input->post('email');
      $this->load->model('queries');
      $data['result'] = $this->queries->fetch_indi_profile($data);
      $this->session->set_flashdata('error','There is an error, please check your input');
      // $this->session->set_flashdata('email',$data);
      // $this->edit();
      // redirect('/agent_controller/edit');

      $this->load->view('pages/ProfileIndividual',$data);
      $this->session->sess_destroy();

    }
    else
    {
      $this->load->model('queries');
      // $roleID = '1';
      $data = array(
      'email' => $this->input->post('email'),
      // 'E_Name' => $this->input->post('name'),
      // 'E_Responsible' => $this->input->post('responsible'),
      // 'E_place' => $this->input->post('place'),
      // 'E_hour' => $this->input->post('hour'),
      // 'E_ticket_value' => $this->input->post('price'),
      // 'E_date' => $this->input->post('date')
    );
      // 'U_role_ID' => $this->input->post('1'));
      //Transfering data to Model
      $this->queries->edit_indi_profile($data);
      // $data['message'] = 'Data Inserted Successfully';
      //Loading View
      $data['email'] = $this->input->post('email');
      $this->load->model('queries');
      $data['result'] = $this->queries->fetch_indi_profile($data);

      $this->load->view('pages/ProfileIndividual',$data);
      $this->session->sess_destroy();
    }

}


function contact()
{
// $this->load->library('form_validation');

$this->form_validation->set_error_delimiters('<div class="error">', '</div>');

$this->form_validation->set_rules('email', 'Email',  'required|valid_email');
$this->form_validation->set_rules('fname', 'first name',  'required|regex_match[/^([A-Za-z ]+)$/]');
$this->form_validation->set_rules('lname', 'last name', 'required|regex_match[/^([A-Za-z ]+)$/]');
$this->form_validation->set_rules('topic', 'Topic', 'required');
$this->form_validation->set_rules('message', 'Message', 'required');

if ($this->form_validation->run() == FALSE)
{
  $this->session->set_flashdata('error','There is an error, please check your input');
  $this->load->view('pages/contact');
  $this->session->sess_destroy();

}
else
{
  $this->load->model('queries');
  // $roleID = '1';
  $data = array();
  // 'U_Email' => $this->input->post('email'),
  // 'U_Password' => $this->input->post('password'),
  // 'U_Last_Name' => $this->input->post('fname'),
  // 'U_First_Name' => $this->input->post('lname'),
  // 'U_address' => $this->input->post('address'),
  // 'U_city' => $this->input->post('city'),
  // 'U_state' => $this->input->post('select'),
  // 'U_postal_code' => $this->input->post('ZipCode'));
  // 'U_role_ID' => $this->input->post('1'));
  //Transfering data to Model
  $this->queries->form_contact($data);
  // $data['message'] = 'Data Inserted Successfully';
  //Loading View

  $this->load->view('pages/contact');
  $this->session->sess_destroy();
}
}

function buyfromus2()
{
  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

  $this->form_validation->set_rules('quant', 'Quantity', 'required');
  if ($this->form_validation->run() == FALSE)
  {
    $email = $this->input->post('email');
    // echo $email;
    $product_description = $this->input->post('pd');
    // echo $product_description;
    $product_price = $this->input->post('pp');
    // echo $product_price;
    $quant = $this->input->post('quant');
    $this->session->set_flashdata('error','There is an error, please select a quantity');
    redirect('/buyfromus/view2/'.$product_description.'/'.$product_price.'/'.$email);
    // $this->load->view('pages/contact');
    $this->session->sess_destroy();

  }
  else
  {
    $this->load->model('queries');
    // $roleID = '1';
    $data = array();
    // 'U_Email' => $this->input->post('email'),
    // 'U_Password' => $this->input->post('password'),
    // 'U_Last_Name' => $this->input->post('fname'),
    // 'U_First_Name' => $this->input->post('lname'),
    // 'U_address' => $this->input->post('address'),
    // 'U_city' => $this->input->post('city'),
    // 'U_state' => $this->input->post('select'),
    // 'U_postal_code' => $this->input->post('ZipCode'));
    // 'U_role_ID' => $this->input->post('1'));
    //Transfering data to Model
    $this->queries->buyfromus2_insert($data);
    // $data['message'] = 'Data Inserted Successfully';
    //Loading View
    $email = $this->input->post('email');
    $product_description = $this->input->post('pd');
    $product_price = $this->input->post('pp');
    $quant = $this->input->post('quant');
    redirect('/buyfromus/view2/'.$product_description.'/'.$product_price.'/'.$email);
    // $this->load->view('pages/contact');
    $this->session->sess_destroy();
  }
}

function business_profile(){
	  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
    $this->form_validation->set_rules('fname', 'First Name',  'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('foundname', 'Foundation Name', 'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
    $this->form_validation->set_rules('phone', 'Phone', 'required|regex_match[/^(\(?\s*\d{3}\s*[\)–\.]?\s*)?[2-9]\d{2}\s*[–\.]\s*\d{4}$/]');
    $this->form_validation->set_rules('username', 'Username', 'required|regex_match[/^([A-Za-z ]+)$/]');
    $this->form_validation->set_rules('password', 'Password', 'required|regex_match[/^[a-zA-Z]\w{8,16}$/]');

    if ($this->form_validation->run() == FALSE)
    {
      $data['email'] = $this->input->post('email');
      $this->load->model('queries');
      $data['result'] = $this->queries->fetch_business_profile($data);
      $this->session->set_flashdata('error','There is an error, please check your input');
      // $this->session->set_flashdata('email',$data);
      // $this->edit();
      // redirect('/agent_controller/edit');

      $this->load->view('pages/ProfileBusiness',$data);
      $this->session->sess_destroy();

    }
    else
    {
      $this->load->model('queries');
      // $roleID = '1';
      $data = array(
      'email' => $this->input->post('email'),
      // 'E_Name' => $this->input->post('name'),
      // 'E_Responsible' => $this->input->post('responsible'),
      // 'E_place' => $this->input->post('place'),
      // 'E_hour' => $this->input->post('hour'),
      // 'E_ticket_value' => $this->input->post('price'),
      // 'E_date' => $this->input->post('date')
    );
      // 'U_role_ID' => $this->input->post('1'));
      //Transfering data to Model
      $this->queries->edit_business_profile($data);
      // $data['message'] = 'Data Inserted Successfully';
      //Loading View
      $data['email'] = $this->input->post('email');
      $this->load->model('queries');
      $data['result'] = $this->queries->fetch_business_profile($data);

      $this->load->view('pages/ProfileBusiness',$data);
      $this->session->sess_destroy();
    }

}


}



?>
