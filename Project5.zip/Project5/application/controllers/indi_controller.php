<?php
class indi_controller extends CI_Controller{
	public function home($page = 'HomeIndividual'){
		if (!file_exists(APPPATH.'views/pages/'.$page.'.php')){
			show_404();
			}
      $email = $this->session->flashdata('email');
      // echo $email;
      $data = array('email' => $email);
      $this->load->model('queries');
      $data['result'] = $this->queries->fetch_indi_business($data);
      // print_r($data);
      // print_r($data['result']);
		// $data['title'] = ucfirst($page);
    $this->load->view('pages/header_view_indi',$data);
		$this->load->view('pages/'.$page, $data);
    $this->load->view('pages/footer_view');
	}
  public function buy($page = 'BuyFromUs1'){
    if (!file_exists(APPPATH.'views/pages/'.$page.'.php')){
      show_404();
      }
    // $data['title'] = ucfirst($page);
    $this->load->view('pages/header_view1');
    $this->load->view('pages/'.$page);
    $this->load->view('pages/footer_view');
  }
  public function profile($page = 'ProfileIndividual'){
    if (!file_exists(APPPATH.'views/pages/'.$page.'.php')){
      show_404();
      }
    // $data['title'] = ucfirst($page);
    // $this->load->view('pages/header_view_indi');
    $email = $this->session->flashdata('email');
    echo $email;
    $data = array('email' => $email);
    $this->load->model('queries');
    $data['result'] = $this->queries->fetch_indi_profile($data);
    print_r($data);
    $this->load->view('pages/'.$page,$data);
    // $this->load->view('pages/footer_view');
  }
}
?>
