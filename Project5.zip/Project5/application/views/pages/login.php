<!DOCTYPE html>
<html lang="en">
  <body id="body">
    <div id="wrapper">
  <main>
    <div class="imagediv">
    <img class="bannercontacto"src="<?php echo base_url().'/assets/imagenes/bannerlogin.jpg' ?>" alt="bannerlogin">
    <div style="margin-left: 33%; margin-top: 5%; " class="textdiv">
      <p style="font-size: 23px; margin:0 0 2px 10px;"><strong>INICIAR SESION</strong></p>
      <div style="display: inline-flex; margin-left: 20px;  "class="">
        <nav style="margin: 0; font-size: 12px; width:100%; overflow:hidden;">
          <ul style="margin: 0; padding: 0 ">
            <li><a 	href="<?php echo base_url() ?>">INICIO</a></li>
            <li><a	href="<?php echo base_url().'login/view';?>">INICIAR SESION</a></li>
          </ul>

        </nav>
      </div>
    </div>
    </div>
    <!-- <form action = "Login.php" onsubmit="return validateform()" method = "Post"> -->
      <?php echo form_open('validate_ctrl/login') ?>
    <div class="smallbox">
      <div class="innersmallbox">

        <p style="font-size: 18px; padding-top: 20px; ">Iniciar Sesion</p>
        <div class="smallboxinline">
          <div class="smallboxinline1">
            <?php echo form_label('Nombre de Usuario') ?>
            <?php echo form_error('email'); ?>
            <!-- <label style="font-size: 12px; "for="">Nombre de Usuario <br> </label> -->
            <?php echo form_input(array('id' => 'email', 'name'=>'email','placeholder'=>'Nombre de Usuario o Correo')) ?>
            <!-- <input type="email" name="email" id="email" value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>" placeholder="Nombre de Usuario o Correo" required> -->
						<p id="emailmsg"> </p>
					</div>
          <div class="smallboxinline2">
            <?php echo form_label('Contrasena') ?>
            <?php echo form_error('password'); ?>
            <!-- <label style="font-size: 12px; " for="">Contrasena <br> </label> -->
            <?php echo form_input(array('id' => 'password', 'name'=>'password','type' => 'password','placeholder'=>'Contrasena')) ?>
            <!-- <input type="password" name="password" id="password" value="" placeholder="Contrasena" required> -->
						<p id="passwordmsg"> </p>
          </div>

        </div>
        <p style="margin-left: 35%; margin-top: 30px;  color: #FFC300; ">Olvido su contrasena?</p>
          <?php echo form_submit(array('id' => 'submit', 'value' => 'Entra','class' => 'button1')); ?>
          <?php echo form_close(); ?>
      	<!-- <button style='width: 80px; margin-left: 40%; margin-bottom: 50px;' class='button1'type='submit' name='login'>Entra</button> -->


      </div>
    </div>
  </form>
      <?php echo $this->session->flashdata("success"); ?>
      <?php echo $this->session->flashdata("error"); ?>
    </main>
    <div class="footerbottom">
      <p class="pfooterbottom"><strong>LEAN EN LAS REDES SOCIALES</strong></p>
      <div class="sociallogos">
        <p class="tfiicons"><i class="fa fa-twitter"></i></p>
        <p class="tfiicons"><i class="fa fa-facebook"></i></p>
        <p class="tfiicons"><i class="fa fa-instagram"></i></p>
      </div>
    </div>
      </div>
      </body>
      </html>
