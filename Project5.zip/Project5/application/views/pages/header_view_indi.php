<?php
// print_r($result);
echo $email;
$this->session->set_flashdata('email',$email);
// $data= array('email'=> $email);?>

<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<link rel="stylesheet" href="<?php echo base_url().'/assets/CSS/leanevent.css'?>"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
<body id="body">
  <div id="wrapper">
    <header>
      <div class="header">
          <img class="faviconimg" style="width: 5%;
  height: 5%;
  margin-top: 1%;" src="<?php echo base_url().'/assets/imagenes/logo-blanco.png'?>" alt="logo" />
        <h1>LEANEVENTOS</h1>
        <!-- <nav style="margin-left: 55%; width:14%; "> -->
        <nav style=" margin-left: 40%; margin-top: 2%; width: 35%;">
          <ul style=" font-size: 10px;">
            <li><a 	href="<?php echo base_url().'indi_controller/home'?>">Inicio</a></li>
              <li><a	href="<?php echo base_url().'buyfromus/view'?>">Comprar Boletos</a></li>
            <li><a href="<?php echo base_url().'indi_controller/profile'?>">Individual</a></li>
          </ul>
        </nav>
      </div>
    </header>
  </div>
</body>
  </html>
