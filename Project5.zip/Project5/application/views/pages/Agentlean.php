<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="<?php echo base_url().'/assets/CSS/leanevent.css'?>"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>

</head>

<body id="body">
  <div id="wrapper">
  <main>
    <div class="registerIndividual">
      <p>Registro Individual</p>
      <hr>
        <?php echo form_open('validate_ctrl/agentlean'); ?>
      <!-- <form class="" action="Individual.php"  onsubmit="return validateform()"  method="post"> -->
        <div style="width : 50%; float:left; "class="">
          <fieldset class="fourinputs">
              <?php echo form_label('Correo'); ?>
              <?php echo form_error('email'); ?>
              <div class="input1">
              <?php echo form_input(array('id' => 'email', 'name'=>'email','placeholder'=>'Correo', 'class' => 'input1')); ?>
              </div>

            <!-- <label for="">Correo</label> -->
            <!-- <input class="input1" type="email" name="email" id="email" value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>" placeholder="Correo" required> -->
            <p id="emailmsg"> </p>
              <?php echo form_label('Nombre'); ?>
            <!-- <label for="">Nombre</label> -->
              <?php echo form_error('fname'); ?>
              <div class="input2">
                    <?php echo form_input(array('id' => 'fname', 'name'=>'fname','placeholder'=>'Nombre', 'class' => 'input1')); ?>
              </div>

            <!-- <input class="input2" type="text" name="fname" id="fname" value="<?php if(isset($_POST['fname'])) echo $_POST['fname']; ?>" placeholder="Nombre" required> -->
            <p id="fnamemsg"> </p>
          </fieldset>

        </div>
        <div style="width: 50%; float: right;" class="">
          <fieldset class="fourinputs">
            <?php echo form_label('Contrasena'); ?>
            <?php echo form_error('password'); ?>
            <!-- <label for="">Contrasena</label> -->
            <div class="input1">
              <?php echo form_password(array('id' => 'password', 'name'=>'password', 'type' => 'password','placeholder'=>'Contrasena', 'class' => 'input1')); ?>
            </div>

            <!-- <input class="input1" type="password" name="password" id="password" value=""  placeholder="Contrasena" required> -->
            <p id="passwordmsg"> </p>
            <?php echo form_label('Apellido'); ?>
              <?php echo form_error('lname'); ?>
            <!-- <label for="">Apellido</label> -->
            <div class="input2">
              <?php echo form_input(array('id' => 'lname', 'name'=>'lname','placeholder'=>'Apedillo','class' => 'input2')); ?>
            </div>

            <!-- <input class="input2" type="text" name="lname" id="lname" value="<?php if(isset($_POST['lname'])) echo $_POST['lname']; ?>" placeholder="Apellido" required> -->
            <p id="lnamemsg"> </p>
          </fieldset>
        </div>
            <?php echo form_label('Direccion'); ?>
              <?php echo form_error('address'); ?>
          <!-- <label for="">Direccion</label> -->
          <div class="input1">
            <?php echo form_input(array('id' => 'address', 'name'=>'address','placeholder'=>'Direccion','class' => 'input1')); ?>
          </div>

          <!-- <input class="input1" type="text" name="address" id="address" value="<?php if(isset($_POST['address'])) echo $_POST['address']; ?>" placeholder="Direccion" required> -->
          <p id="addressmsg"> </p>
            <?php echo form_label('Ciudad'); ?>
              <?php echo form_error('city'); ?>
          <!-- <label for="">Ciudad</label> -->
            <div class="input1">
              <?php echo form_input(array('id' => 'city', 'name'=>'city','placeholder'=>'Ciudad', 'class' => 'input1')); ?>
            </div>
          <!-- <input class="input1" type="text" name="city" id="city" value="<?php if(isset($_POST['city'])) echo $_POST['city']; ?>" placeholder="Ciudad" required> -->
          <p id="citymsg"> </p>
          <div style="width : 70%; float:left; "class="">
            <fieldset class="fourinputs">
              <?php echo form_label('Estado'); ?>
                <?php echo form_error('state'); ?>
              <!-- <label for="">Estado</label> -->
              <div class="">
                <?php $data_state = array(
                  'New York' =>'New York',
                    'Mountain View,CA' => 'Mountain View,CA',
                  'LA,CA' => 'LA,CA',
                'Dallas' => 'Dallas') ?>
                <?php echo form_dropdown('select', $data_state, 'New York', 'class = "dropitdown"'); ?>
              </div>
              <!-- <select style="margin-top: 5px; height: 55px; width: 100%; margin-bottom: 25px;" name="state" id="state" placeholder="Escoger..."> -->
                <!-- <option>New York</option>
                <option>Mountain View,CA</option>
                <option>LA,CA</option>
                <option>Dallas</option>
              </select> -->
              <p id="statemsg"> </p>
            </fieldset>

          </div>
          <div style="width: 30%; float: right;" class="">
            <fieldset style="margin-top: 4px; " class="fourinputs">
                <?php echo form_label('Codigo Postal'); ?>
                <?php echo form_error('ZipCode'); ?>
              <!-- <label for="">Codigo Postal</label> -->
                  <?php echo form_input(array('id' => 'ZipCode', 'name'=>'ZipCode','placeholder'=>'Codigo Postal', 'class'=> 'input1')); ?>
              <!-- <input class="input1" type="text" name="ZipCode" id="ZipCode" value="<?php if(isset($_POST['ZipCode'])) echo $_POST['ZipCode']; ?>" placeholder="" required> -->
              <p id="Zipmsg"> </p>
            </fieldset>
          </div>
          <div style="margin-right: 90%;">
            <?php echo form_submit(array('id' => 'submit', 'value' => 'Registrarse','class' => 'button1')); ?>
          </div>
          <?php echo form_close(); ?>

          <!-- <button style="margin-right: 90%;" class="button1" type="submit"  name="users1">
            Registrarse
          </button> -->
          <hr>
        <a href="<?php echo base_url().'sign/view' ?>"><button class="button2" type="button" name="button">
            Cerrar
          </button></a>

      <!-- </form> -->
      <?php echo $this->session->flashdata("success"); ?>
      <?php echo $this->session->flashdata("error"); ?>

    </div>
  </main>
</div>
</body>
</html>
