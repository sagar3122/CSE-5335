<!DOCTYPE html>
<html lang="en">
<body id="body">
  <div id="wrapper">
<div>
  <footer>
    <div class= "lowestfooter1">
    <p><br>Copyright &copy2019 All rights reserved | This web is made with &#9825; by <span style="color: #FFC300;">DiazApps</span></p>
    </div>
    <div class="lowestfooter2">
    <button class="button1" type="button" name="button">&#8593;</button>
    </div>


  </footer>
</div>
</div>
</body>
</html>
