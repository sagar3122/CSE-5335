<?php
// print('yes');
echo $email;
// print_r($result); ?>

<!DOCTYPE html>
<html lang="en">
<body id="body">
  <div id="wrapper">
  <main>
    <table>
      <caption>Lista de Eventos</caption>
      <thead>
        <tr>
          <th style="text-align: center;" colspan="10">Detalles Del Eventos</th>
          <th style="text-indent: 15px;">Lugar</th>
          <th style="text-indent: 5px;">Fecha</th>
          <th>Hora</th>
          <th style="text-indent: 5px;">Asistencia</th>
        </tr>
      </thead>
      <tbody>
        <?php
        foreach($result as $row)
        {
        echo  "<tr>
            <td> <img src=".base_url()."/assets/imagenes/minibaner1.jpg alt='minibanner1'> </td>
            <td>".$row->E_Name."</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>".$row->E_place."</td>
            <td>".$row->E_date."</td>
            <td>".$row->E_hour."</td>
            <td> <button style='width: 80%; height: 35px; ' class='button1' type='button' name='button'>
              Confirmar
            </button></button> </td>
          </tr>";
        }

?>
        <!-- // <tr>
        //   <td> <img src="imagenes/minibaner2.jpg" alt="minibanner2"> </td>
        //   <td>Nombre del Evento y sus detalles</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>Direccion del lugar</td>
        //   <td>14/01/2019</td>
        //   <td>8 AM</td>
        //   <td> <button style="width: 80%; height: 35px;" class="button1" type="button" name="button">
        //     Confirmar
        //   </button></button> </td>
        // </tr>
        // <tr>
        //   <td> <img src="imagenes/minibaner3.jpg" alt="minibanner3"> </td>
        //   <td>Nombre del Evento y sus detalles</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>&nbsp;</td>
        //   <td>Direccion del lugar</td>
        //   <td>14/01/2019</td>
        //   <td>8 AM</td>
        //   <td> <button style="width: 80%; height: 35px;" class="button1" type="button" name="button">
        //     Confirmar
        //   </button></button> </td>
        // </tr> -->
      </tbody>
    </table>
  </main>

    </div>


  </body>
  </html>
