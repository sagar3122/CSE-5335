<?php
// $email = $this->session->flashdata('email');
echo $email;
// $this->session->set_flashdata('email',$email);
// $data = array('email' => $email);
// $this->load->model('queries');
// $data['result'] = $this->queries->fetch_agent_profile($data);
// print_r($data);
 ?>

 <!DOCTYPE html>
 <html lang="en" dir="ltr">
 <head>
   <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
 <link rel="stylesheet" href="<?php echo base_url().'/assets/CSS/leanevent.css'?>"/>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
 </head>
 <body id="body">
   <div id="wrapper">
     <header><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
   <div class="header">
       <img class="faviconimg" style="width: 5%;
 height: 5%;
 margin-top: 1%;" src="<?php echo base_url().'/assets/imagenes/logo-blanco.png'?>" alt="logo" />
     <h1>LEANEVENTOS</h1>
     <!-- <nav style="margin-left: 55%; width:14%; "> -->
     <nav style=" margin-left: 40%; margin-top: 2%; width: 35%;">
       <ul style=" font-size: 10px;">
         <li><a 	href="<?php echo base_url().'indi_controller/home'?>">Inicio</a></li>
         <li><a	href="<?php echo base_url().'buyfromus/view'?>">Comprar Boletos</a></li>
         <li><a	href="<?php echo base_url().'indi_controller/profile'?>">Individual</a></li>
       </ul>
     </nav>
   </div>
 </header>
         <main>
           <div class="imagediv">
           <img class="bannercontacto"src="<?php echo base_url().'/assets/imagenes/bannercontacto.jpg'?>" alt="bannercontacto">
           <div style="margin-left: 35%; margin-top:4%;" class="textdiv">
             <p style="font-size: 22px; margin:0 0 2px 10px;"><strong>PERFIL</strong></p>
             <div style="margin-left: 5px; margin-top: 5px;  "class="">
             <nav style="margin: 0; font-size: 12px; width:100%; overflow:hidden;">
               <ul style="margin: 0; padding: 0 ">
                 <li><a 	href="<?php echo base_url().'indi_controller/home'?>">INICIO</a></li>
                 <li><a	href="<?php echo base_url().'indi_controller/profile'?>">PERFIL</a></li>
               </ul>

             </nav>
             </div>
             </div>
             </div>
       <?php
       foreach($result as $row)
       {
         echo "<div class='profilediv'>
           <p style='margin-bottom: 0; font-size: 18px; '> <strong>Tu Informacion del Perfil</strong> </p>
           <div style='font-size: 11px;'class='innerprofilediv'>
             <div class='leftprofilediv'>
               <p style='color: black;'><i class='fa fa-book'></i> &nbsp;".$row->U_First_Name."</p>
               <p style='color: black;'><i class='fa fa-book'></i> &nbsp;".$row->U_Last_Name."</p>
               <p style='color: black;'><i class='fa fa-user'></i> &nbsp;".$row->U_Username."</p>

             </div>
             <div class='middleprofilediv'>
               <p style='color: black; '><i class='fa fa-map-marker'></i> &nbsp;".$row->U_address."</p>
               <p style='color: black;'><i class='fa fa-phone'></i> &nbsp;".$row->U_Phone."</p>
               <p style='color: black;'><i class='fa fa-paper-plane-o'></i> &nbsp;".$row->U_Email."</p>

             </div>
             <div class='rightprofilediv'>
               <img style=' width: 60%; height: 100px; ' src=".base_url()."/assets/imagenes/nologo.png alt='nologo'>
             </div>
           </div>
         </div>";
       }

        ?>
            <?php echo form_open('validate_ctrl/indi_profile'); ?>
       <!-- <form action="ProfileAgentSubMenu.php?email=<?php echo $_GET['email'];?>" onsubmit=" return validateform()" method="post"> -->
       <div class="contactdiv">
         <div class="innercontactdiv">
           <p style="font-size: 20px;"><br><strong>Estar en contacto</strong></p>
           <hr>
           <div class="innercontactdivform">
             <div class="innercontactdivform1">
               <?php echo form_label('Nombres'); ?>
               <?php echo form_error('fname'); ?>
               <!-- <label for="">Nombres</label> -->
                 <?php echo form_input(array('id' => 'fname', 'name'=>'fname','placeholder'=>'Tu Nombre')); ?>
               <!-- <input type="text" name="fname" id="fname" value="<?php if(isset($_POST['fname'])) echo $_POST['fname'];  ?>" placeholder="Tu Nombre" required> -->
               <p id="fnamemsg"> </p>
               <?php echo form_label('Apedillos'); ?>
               <?php echo form_error('lname'); ?>
               <!-- <label for="">Nombre de Registro del Inscrito</label> -->
                 <?php echo form_input(array('id' => 'lname', 'name'=>'lname','placeholder'=>'Tu Apedillos')); ?>
               <!-- <input type="text" name="rname" id="rname"value="<?php if(isset($_POST['rname'])) echo $_POST['rname'];  ?>" placeholder="Nombre de Registro del Inscrito" required> -->
               <p id="rnamemsg"> </p>
             </div>
             <div class="innercontactdivform2">
               <img src="<?php echo base_url().'/assets/imagenes/user.png'?>" alt="nologo">
               <button type="button" name="button">
               Seleccionar Logo</button>

             </div>
           </div>
           <?php echo form_label('Correo'); ?>
           <br>
           <?php echo form_error('email'); ?>
           <!-- <label style=" " for="">Correo</label><br> -->
               <?php echo form_input(array('id' => 'email', 'name'=>'email','placeholder'=>'Tu correo electronico', 'class'=>'innercontactdivinput')); ?>
           <!-- <input class="innercontactdivinput"style=" " type="email" name="email" id="email"value="<?php if(isset($_POST['email'])) echo $_POST['email'];  ?>" placeholder="Tu correo electronico" required> -->
           <p id="emailmsg"> </p>
           <div class="innermostcontactdivinline">
             <div class="icdiv1">
               <?php echo form_label('Telephono'); ?>
               <br>
               <?php echo form_error('phone'); ?>
               <!-- <label for=""></label>Telefono <br> -->
                 <?php echo form_input(array('id' => 'phone', 'name'=>'phone','placeholder'=>'Telefono')); ?>
               <!-- <input type="text" name="phone" id="phone" value="<?php if(isset($_POST['phone'])) echo $_POST['phone'];  ?>" placeholder="Telefono" required> -->
             </div>
             <p id="phonemsg"> </p>
             <div class="icdiv1">
               <?php echo form_label('Usuario'); ?>
               <br>
               <?php echo form_error('username'); ?>
               <!-- <label for=""></label>Usuario <br> -->
                   <?php echo form_input(array('id' => 'username', 'name'=>'username','placeholder'=>'Nombre de Usuario')); ?>
               <!-- <input type="text" name="username" id="username"value="<?php if(isset($_POST['username'])) echo $_POST['username'];  ?>" placeholder="Nombre de Usuario" required> -->
               <p id="usernamemsg"> </p>
             </div>
             <div class="icdiv1">
               <?php echo form_label('Contrasena'); ?>
               <br>
               <?php echo form_error('password'); ?>
               <!-- <label for=""></label>Contrasena <br> -->
                 <?php echo form_input(array('id' => 'password', 'name'=>'password', 'type'=>'password','placeholder'=>'Contrasena')); ?>
               <!-- <input type="password" name="password" id="password" value="<?php if(isset($_POST['password'])) echo $_POST['password'];  ?>" placeholder="Contrasena" required> -->
               <p id="passwordmsg"> </p>
             </div>


           </div>
               <?php echo form_submit(array('id' => 'nota', 'value' => 'Nota','class' => 'proindismallbutton')); ?>
           <!-- <button class="proindismallbutton" type="button" name="button">Nota:</button> -->

           <p style="margin: 0; font-weight:lighter; font-size: 11px; ">Solo puede cambiar los datos(Telefono,Contrasena y Foto)</p>
           <?php
           // try{
           //     if(empty($_GET['email']))
           //     {
           //       echo "<button style='margin-left: 40%; margin-top: 10px; height: 35px; width: 150px;  margin-bottom: 40px;' class='button1'type='submit' value = '' name='prolean'><small>Guardar Cambios</small></button>";
           //       throw new Exception();
           //
           //     }
           //     else{
               echo form_hidden('email',$email);
                   echo form_submit(array('id' => 'submit', 'value' => 'Guardar Cambios','class' => 'button1'));
                 // echo "<button style='margin-left: 40%; margin-top: 10px; height: 35px; width: 150px;  margin-bottom: 40px;' class='button1'type='submit' value = '".$_GET['email']."' name='prolean'><small>Guardar Cambios</small></button>";
           //     }
           //
           // }
           // catch(Exception $e)
           // {
           //   // echo 'updated' .$e->getMessage();
           // }

           // echo $_POST['prolean'];
           // echo $_POST['prolean'];
             ?>
               <?php echo form_close(); ?>
               <?php echo $this->session->flashdata("success"); ?>
               <?php echo $this->session->flashdata("error"); ?>
         </div>
       </div>
       </form>
     </main>
     <div class="footer">
       <div class="footerbottom">
         <div>
           <footer>
             <div class= "lowestfooter1">
             <p><br>Copyright &copy2019 All rights reserved | This web is made with &#9825; by <span style="color: #FFC300;">DiazApps</span></p>
             </div>
             <div class="lowestfooter2">
             <button class="button1" type="button" name="button">&#8593;</button>
             </div>
           </footer>
         </div>
       </div>
     </div>
   </body>
 </html>
