<!DOCTYPE html>
<html lang="en">
<body id="body">
  <div id="wrapper">
  <main>
    <div class="firstimage">
        <img class="banerlean2" src="<?php echo base_url().'/assets/imagenes/bannerlean2.jpg' ?>"	alt="banerlean2"	/>
        <img class="logoblanco" src="<?php echo base_url().'/assets/imagenes/logo-blanco.png' ?>" alt="logoblanco" />
    </div>

    <div class="wrapper">
      <p class="Firstpara"><h4><span>¿QUÉ HACEMOS?</span></h4></p>
      <p class="Secondpara">La asociación civil LEAN fue creada con el objetivo de ayudar, a través de acciones concretas, a nuestros
        conciudadanos en Venezuela ante la grave escasez de medicinas e insumos médicos en que se
        encuentra el país. Nuestra misión consiste en recolectar ayuda médico sanitaria en delegaciones en
        España y, a través de agentes de transporte, llevarlos a Venezuela para que otras asociaciones se
        encarguen de su distribución. De esta manera aportamos nuestro granito de arena ayudando a llevar
        asistencia humanitaria a Venezuela. Somos una asociación sin fines de lucro, dedicada a la defensa de
        los Derechos Humanos</p>
      </div>
      <div class="onbottom">
      <img class="bannerabout" src="<?php echo base_url().'/assets/imagenes/bannerabout.jpg' ?>"	alt="bannerabout"	/>
      <div class="ontop1">
        <p><h3>478 <br>VOLUNTARIOS</h3></p>
        <p><h3>60.000 <br> PERSONAS BENEFICIADAS</h3></p>
        <p><h3>45 <br> ALIADOS</h3></p>
      </div>
      <div class="ontop2">
        <p class="quote"><strong>"La injusticia, en cualquier parte, es una amenaza a la justicia en todas partes.</strong>"</p>
        <p class="subquote"><br><i><sub>Martin Luter King</sub></i></p>
      </div>
      </div>

      <div class="wrapper">
        <p class="Thirdpara">
        <h4 class="aliados"><span>ALIADOS</span></h4>
        </p>
        <img class="sponsorimages1" src="<?php echo base_url().'/assets/logo/logo1.PNG' ?>"	alt="logo1"	/>
        <img class="sponsorimages1" src="<?php echo base_url().'/assets/logo/logo2.PNG' ?>"	alt="logo2"	/>
        <img class="sponsorimages2" src="<?php echo base_url().'/assets/logo/logo3.PNG' ?>"	alt="logo3"	/>
        <img class="sponsorimages2" src="<?php echo base_url().'/assets/logo/logo4.PNG' ?>"	alt="logo4"	/>
    </div>
    <div class="homebuttondiv">
      <button type="button" name="button"><</button>
      <button type="button" name="button">></button>
    </div>
  </main>
<div class="footer">

    <form class="subscribe" action="HomePage.php" method="post" onsubmit="return validateform()">
      <fieldset>
        <label class="subscribelabel" for=""><strong><i class="fa fa-paper-plane-o"></i> &nbsp;Registrese para reciber un <br>boletin</strong></label>
        <input class="subscribetext" type="email" name="email" id="email" value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>" placeholder="Introduce tu correo electronico" required>

        <button class="subscribebutton" type="submit" name="subscriber">Suscribir</button>

      </fieldset>
    </form>
    <p id="emailmsg"></p>

    <div class="footerbottom">
      <p class="pfooterbottom"><strong>LEAN EN LAS REDES SOCIALES</strong></p>
      <div class="sociallogos">
        <p class="tfiicons"><i class="fa fa-twitter"></i></p>
        <p class="tfiicons"><i class="fa fa-facebook"></i></p>
        <p class="tfiicons"><i class="fa fa-instagram"></i></p>
      </div>

    </div>

  </div>
</div>
</body>
</html>
