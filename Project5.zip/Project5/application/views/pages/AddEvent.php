<?php
// echo $edit;
$email = $this->session->flashdata('email');
echo $email;
// print_r($data['edit']);
?>
<!DOCTYPE html>
<html lang="en">
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<link rel="stylesheet" href="<?php echo base_url().'/assets/CSS/leanevent.css'?>"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
  <body id="body">
    <div id="wrapper">
    <header><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
      <div class="header">
          <img class="faviconimg" style="width: 5%;
  height: 5%;
  margin-top: 1%;" src="<?php echo base_url().'/assets/imagenes/logo-blanco.png'?>" alt="logo" />
        <h1>LEANEVENTOS</h1>
        <!-- <nav style="margin-left: 28%; width:48%;"> -->
        <nav style=" margin-left: 21%; margin-top: 2%; width: 48%;">
            <ul style=" font-size: 10px;">
            <li><a 	href="<?php echo base_url().'HomeAgentLean' ?>">Inicio</a></li>
            <li><a	href="<?php echo base_url().'ListIndividual'?>">Lista de Voluntarios</a></li>
            <li><a	href="<?php echo base_url().'ListBusiness' ?>">Lista de Fundacion</a></li>
            <li><a	href="<?php echo base_url().'agent_controller/home'?>">Eventos</a></li>
            <li><a href="<?php echo base_url().'pages/ProfileAgentSubMenu'?>"> Agente</a></li>

          </ul>
        </nav>
      </div>
    </header>
      <main>
        <div class="imagediv">
        <img class="bannercontacto"src="<?php echo base_url().'/assets/imagenes/bannerregistro.jpg'?>" alt="bannerregistro">
        <div style="margin-left: 32%; margin-top: 5%; " class="textdiv">
          <p style="font-size: 20px; margin:0 0 2px 20px;"><strong>REGISTRO DE EVENTO</strong></p>
          <div style="display: inline-flex; margin-left: 52px;  "class="">
            <nav style="margin: 0; font-size: 12px; width:100%; overflow:hidden;">
              <ul style="margin: 0; padding: 0 ">
                <li><a 	href="<?php echo base_url().'HomeAgentLean'?>">INICIO</a></li>
                <li><a	href="<?php echo base_url().'EditEvent'?>">REGISTRO</a></li>
              </ul>

            </nav>
          </div>
        </div>
        </div>
         <?php echo form_open('validate_ctrl/agent_event_add'); ?>
        <!-- <form class="" action="EditEvent.php?email=<?php echo $email_pass; ?>" onsubmit=" return validateform()" method="post"> -->
      <div style="margin-top: 100px;" class="contactdiv">
        <div class="innercontactdiv">
          <p style="font-size: 20px;"><br><strong>Registro de Evento</strong></p>
          <hr>
          <div class="innercontactdivform">
            <div class="innercontactdivform1">
              <?php echo form_hidden('email',$email); ?>
                  <?php echo form_label('Nombres'); ?>
                    <?php echo form_error('name'); ?>
              <!-- <label for="">Nombres</label> -->
                <?php echo form_input(array('id' => 'name', 'name'=>'name','placeholder'=>'Nombre del Evento')); ?>
              <!-- <input type="text" name="name" id="name" value="<?php if(isset($_POST['name'])) echo $_POST['name']; ?>" placeholder="Nombre del Evento" required> -->
                <p id="namemsg"> </p>
                <?php echo form_label('Responsable'); ?>
                  <?php echo form_error('responsible'); ?>
              <!-- <label for="">Responsable</label> -->
              <?php echo form_input(array('id' => 'responsible', 'name'=>'responsible','placeholder'=>'Nombre des Responsable')); ?>
              <!-- <input type="text" name="responsible" id="responsible" value="<?php if(isset($_POST['responsible'])) echo $_POST['responsible']; ?>" placeholder="Nombre des Responsable" required> -->
                <p id="responsiblemsg"> </p>
            </div>
            <div class="innercontactdivform2">
              <img src="<?php echo base_url().'/assets/imagenes/imagensubir.png'?>" alt="imagensubir">
              <button style="margin-top:0; " type="button" name="button">
              Seleccionar Imagen</button>

            </div>
          </div>
          <?php echo form_label('Lugar'); ?>
          <?php echo '<br>'; ?>
            <?php echo form_error('place'); ?>
          <!-- <label style=" " for="">Lugar</label><br> -->
                <?php echo form_input(array('id' => 'place', 'name'=>'place','placeholder'=>'Direccion del Lugar del Eventos','class'=>'innercontactdivinput')); ?>
          <!-- <input class="innercontactdivinput"style=" " type="text" name="place" id="place" value="<?php if(isset($_POST['place'])) echo $_POST['place']; ?>" placeholder="Direccion del Lugar del Eventos" required> -->
          <p id="placemsg"></p>
          <div class="innermostcontactdivinline">
            <div class="icdiv1">
              <?php echo form_label('Fetcha'); ?>
                <?php echo form_error('date'); ?>
              <!-- <label for=""></label>Fecha <br> -->
              <?php echo form_input(array('id' => 'date', 'name'=>'date','placeholder'=>'mm/dd/yyyy')); ?>
              <!-- <input type="text" name="date" id="date" value="<?php if(isset($_POST['date'])) echo $_POST['date']; ?>" placeholder="mm/dd/yyyy" required> -->
                <p id="datemsg"> </p>
            </div>
            <div class="icdiv1">
              <?php echo form_label('Hora'); ?>
                <?php echo form_error('hour'); ?>
              <!-- <label for=""></label>Hora <br> -->
                <?php echo form_input(array('id' => 'hour', 'name'=>'hour', 'type'=>'time')); ?>
              <!-- <input type="time" name="hour" id="hour" value="<?php if(isset($_POST['hour'])) echo $_POST['hour']; ?>" placeholder="00:00" required> -->
                  <p id="hourmsg"> </p>
            </div>
            <div class="icdiv1">
              <?php echo form_label('Valor de Boleto'); ?>
                <?php echo form_error('price'); ?>
              <!-- <label for=""></label>Valor de Boleto <br> -->
              <?php echo form_input(array('id' => 'price', 'name'=>'price','placeholder'=>'$000.00')); ?>
              <!-- <input type="text" name="price" id="price" value="<?php if(isset($_POST['price'])) echo $_POST['price']; ?>" placeholder="$000.00" required> -->
              <p id="pricemsg"></p>
            </div>


          </div>
            <?php echo form_submit(array('id' => 'submit', 'value' => 'Guardar','class' => 'button1')); ?>
          <!-- <button style="margin-left: 40%; margin-top: 10px; height: 35px; width: 100px;  margin-bottom: 40px;" class="button1"type="submit" name="editevents"><small>Guardar</small></button> -->
            <?php echo form_close(); ?>
        </div>
      </div>
      <?php echo $this->session->flashdata("success"); ?>
      <?php echo $this->session->flashdata("error"); ?>
      <?php
      // echo "editid.$_POST[edit]";
      if (isset($_POST['edit']))
      {
        // echo $_POST['edit2'];

        $id = $_POST['edit'];
        echo "<input type='hidden' name='id'id='id' value=".$id.">";
      }
      // if (isset($_POST['edit1']))
      // {
      //   // echo $_POST['edit1'];
      //   $id = $_POST['edit1'];
      //   echo "<input type='hidden' name='id'id='id' value=".$id.">";
      // }
      //
      // if (isset($_POST['edit3']))
      // {
      //   // echo $_POST['edit3'];
      //   $id = $_POST['edit3'];
      //   echo "<input type='hidden' name='id' id='id' value=".$id.">";
      // }
      ?>
    </form>
    </main>
    <div>
      <footer>
        <div class= "lowestfooter1">
        <p><br>Copyright &copy2019 All rights reserved | This web is made with &#9825; by <span style="color: #FFC300;">DiazApps</span></p>
        </div>
        <div class="lowestfooter2">
        <button class="button1" type="button" name="button">&#8593;</button>
        </div>


      </footer>
    </div>

    </div>
  </body>
</html>
