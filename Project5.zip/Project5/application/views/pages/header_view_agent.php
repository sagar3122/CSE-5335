<?php
// print_r($result);
echo $email;
$this->session->set_flashdata('email',$email);
// $data= array('email'=> $email);?>
<!DOCTYPE html>
<html lang="en">

<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<link rel="stylesheet" href="<?php echo base_url().'/assets/CSS/leanevent.css'?>"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
  <body id="body">
    <div id="wrapper">
    <header><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
      <div class="header">
          <img class="faviconimg" style="width: 5%;
  height: 5%;
  margin-top: 1%;" src="<?php echo base_url().'/assets/imagenes/logo-blanco.png'?>" alt="logo" />
        <h1>LEANEVENTOS</h1>
        <!-- <nav style="margin-left: 28%; width:48%;"> -->
        <nav style=" margin-left: 18%; margin-top: 2%; width: 55%;">
          <ul style=" font-size: 8px;">
            <li><a 	href="<?php echo base_url().'HomeAgentLean' ?>">Inicio</a></li>
            <li><a	href="<?php echo base_url().'ListIndividual'?>">Lista de Voluntarios</a></li>
            <li><a	href="<?php echo base_url().'ListBusiness' ?>">Lista de Fundacion</a></li>
            <li><a	href="<?php echo base_url().'agent_controller/home'?>">Eventos</a></li>
              <li><a	href="<?php echo base_url().'buyfromus/view'?>">Comprar Boletos</a></li>
            <li><a href="<?php echo base_url("agent_controller/profile");?>"> Agente</a></li>

          </ul>
        </nav>
      </div>
    </header>
  </div>
</body>
</html>
