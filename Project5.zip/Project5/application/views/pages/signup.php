<!DOCTYPE html>
<html lang="en">
<body id="body">
<div id="wrapper">
  <main>
    <div class="imagediv">
    <img class="bannercontacto"src="<?php echo base_url().'/assets/imagenes/bannerregistro.jpg' ?>" alt="bannerregistro">
    <div style="margin-left: 32%; margin-top: 5%; " class="textdiv">
      <p style="font-size: 23px; margin:0 0 2px 20px;"><strong>REGISTRATE</strong></p>
      <div style="display: inline-flex; margin-left: 25px;  "class="">
        <nav style="margin: 0; font-size: 12px; width:100%; overflow:hidden;">
          <ul style="margin: 0; padding: 0 ">
            <li><a 	href="<?php echo base_url()?>">INICIO</a></li>
            <li><a	href="<?php echo base_url().'sign/view'?>">REGISTRATE</a></li>
          </ul>

        </nav>
      </div>
    </div>
    </div>
    <div class="signupbox">
      <div class="innersignupbox">
        <p><br>Elija el tipo de usuario para registrarse</p>
        <hr style="color: lightgrey;">
        <div class="innerbuttonline">
          <a href="<?php echo base_url().'/individual'?>"><button  class="button1" type="button" name="button" type="submit">Como individual</button></a>
        <a href="<?php echo base_url().'/business'?>"> <button style="width: 28%; height: 40px;  " class="button1" type="submit" name="button">Como Negocio o Fundacion</button></a>
        <a href="<?php echo base_url().'/Agentlean'?>">  <button style="width: 19%; height: 40px; "class="button1"  type="submit" name="button">Como agente LEAN</button> </a>
        </div>
      </div>
    </div>
    </main>
    <div class="footerbottom">
      <p class="pfooterbottom"><strong>LEAN EN LAS REDES SOCIALES</strong></p>
      <div class="sociallogos">
        <p class="tfiicons"><i class="fa fa-twitter"></i></p>
        <p class="tfiicons"><i class="fa fa-facebook"></i></p>
        <p class="tfiicons"><i class="fa fa-instagram"></i></p>
      </div>

    </div>
    </div>
      </body>
      </html>
