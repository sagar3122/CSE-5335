<!DOCTYPE html>
<html lang="en">
<body id="body">
  <div id="wrapper">
  <main>
    <div class="imagediv">
    <img class="bannercontacto"src="<?php echo base_url().'/assets/imagenes/bannercboleto.jpg'?>" alt="bannercboleto">
    <div style="margin-left: 33%; margin-top:4%;" class="textdiv">
      <p style="font-size: 22px; margin:0 0 2px 0px;"><strong>COMPRAR BOLETOS</strong></p>
      <div style="margin-left: 10px; margin-top: 5px;" class="">
      <nav style="margin: 0; font-size: 12px; width:100%; padding: 0; overflow:hidden;">
        <ul style="margin: 0; padding: 0; ">
          <li><a 	href="<?php echo base_url()?>">INICIO</a></li>
          <li><a	href="<?php echo base_url().'/buyfromus/view'?>">COMPRAR BOLETOS</a></li>
        </ul>

      </nav>
      </div>
      </div>
    </div>
      <div class="buyfromus2div1">
        <div class="leftbuyfromus">
          <img src="<?php echo base_url().'/assets/imagenes/minibaner4.jpg'?>" alt="minibaner4">
        </div>
        <div class="rightbuyfromus">
          <p style="margin-top: 0; "><strong><?php echo $product_des; ?></strong></p>
          <p> <strong>$<?php echo $product_price; ?></strong><span style="color: #FFC300; margin-left:55%; ">&#9733;&#9733;&#9733;&#9733;&#9733;</span> <span style="font-weight: lighter; font-size: 12px;" ><small>(74 Ratings)</small></span> </p>
          <p style="font-weight: lighter; font-size: 12px; margin-bottom: 25px; ">iLa fe no se puede perder JAMAS! Es imprescindible para todo en nuestras vidas,
          poco a poco las cosas iran mejorando.No cambiaran de la noche  a la  manana, pero van  a cambiar y solo cambiaran si te
          lo propones.Si hoy tuvimos un mal dia, nuestra meta sera tener uno mejor manana. Es basicamente hacer nuestra la frase
          "Hoy no me dare por vencido",repitela todos los dias, hazla parte de tu filosofia de vida.<br></p>
          <p style="font-weight: lighter; font-size: 12px; ">Numero De Entrades</p>
          <?php echo form_open('validate_ctrl/buyfromus2'); ?>
          <!-- <form action = "BuyFromUs2.php?Product_Description=<?php echo $product_description;?>&email=<?php echo $email_pass; ?>&Product_Price=<?php echo $product_price;?>" method = "post"> -->
          <?php echo form_hidden('email',$email); ?>
          <?php echo form_hidden('pd',$product_des); ?>
          <?php echo form_hidden('pp',$product_price); ?>
          <div style="display: inline-flex; margin-top: 5px; "class="">
            <button class="smallbuyfromusbuttons" type="" name="button">-</button>
              <?php echo form_input(array('id' => 'quant', 'name'=>'quant','type'=>'number','placeholder'=>'1', 'class'=> 'buyfromus2input')); ?>
            <!-- <input style="margin-left: 20px; margin-right: 20px; margin-top: 10px; " type="number" name="quant" value="" placeholder="1"> -->
            <!-- <p style="margin-left: 20px; margin-right: 20px; margin-top: 10px; ">1</p> -->
            <button class="smallbuyfromusbuttons" type="" name="button">+</button>
          </div>
          <!-- <input type="hidden" name="" value="<?php echo "$product_description";  ?>"> -->
          <!-- <input type="hidden" name="" value="<?php echo "$product_price"; ?>"> -->
          <div style="margin-top: 10px; ">
                  <?php echo form_submit(array('id' => 'submit', 'value' => 'Comprar','class' => 'buyfromus2submit')); ?>
          <!-- <button style="border-radius: 0; height: 35px; width: 100px;" class="button1" type="submit" name="buy_from_us">&#128722; Comprar</button> -->
            <?php echo form_close(); ?>
          <?php echo $this->session->flashdata("success"); ?>
          <?php echo $this->session->flashdata("error"); ?>
          </div>
        <!-- </form> -->
        </div>

      </div>
      <div class="lowerbuyfromus">
        <button  class="button1" type="button" name="button">DESCRIPTION</button>
        <button style="background-color: lightgrey; "  class="button1" type="button" name="button">Encargados</button>
        <button style="background-color: lightgrey; "  class="button1"type="button" name="button">PATROCINANTES</button>
        <div style="font-weight: lighter; font-size: 14px; padding: 10px 20px 10px 30px; " class="buyfromusblock">
          <p>Recien he comenzado a leer un libro cuyo mensaje principal es aprender a buscar ese  algo mejor todos los dias.El libro esta escrito
            por una persona que vive con diabetes tipo 1 y nos presenta como los adelantos en tratamientos technologia ,aunque no han curado su
            condicion, dia tras dia mejoran su calidad de vida.<br><br>
            Busqemos siempre mejorar algo en nuestras vidas , mantengamos el deseo de progresar, de educarnos mas acerca de la condicion de nuestros
            hijos y veras como poco a poco comenzaromos a entenderla mejor.</p>

        </div>

      </div>

</main>
<div class="footer">

    <form class="subscribe" action="index.html" method="post">
      <fieldset>
        <label class="subscribelabel" for=""><strong><i class="fa fa-paper-plane-o"></i> &nbsp;Registrese para reciber un <br>boletin</strong></label>
        <input class="subscribetext" type="text" name="" value="" placeholder="Introduce tu correo electronico">
        <button class="subscribebutton" type="button" name="button">Suscribir</button>
      </fieldset>
    </form>
    <div class="footerbottom">
      <p class="pfooterbottom"><strong>LEAN EN LAS REDES SOCIALES</strong></p>
      <div class="sociallogos">
        <p class="tfiicons"><i class="fa fa-twitter"></i></p>
        <p class="tfiicons"><i class="fa fa-facebook"></i></p>
        <p class="tfiicons"><i class="fa fa-instagram"></i></p>
      </div>

    </div>

  </div>
</div>
</body>
</html>
