<?php
echo $email;
print_r($result);

 ?>
<!DOCTYPE html>
<html lang="en">
  <body id="body">
    <div id="wrapper">
    <main>
      <div class="imagediv">
      <img class="bannercontacto"src="<?php echo base_url().'/assets/imagenes/bannercboleto.jpg'?>" alt="bannercboleto">
      <div style="margin-left: 33%; margin-top:4%;" class="textdiv">
        <p style="font-size: 22px; margin:0 0 2px 0px;"><strong>COMPRAR BOLETOS</strong></p>
        <div style="margin-left: 10px; margin-top: 5px;" class="">
        <nav style="margin: 0; font-size: 12px; width:100%; padding: 0; overflow:hidden;">
          <ul style="margin: 0; padding: 0; ">
            <li><a 	href="<?php echo base_url()?>">INICIO</a></li>
            <li><a	href="<?php echo base_url().'buyfromus/view' ?>">Comprar Boletos</a></li>
          </ul>

        </nav>
        </div>
        </div>
      </div>
      <p style="margin-top: 100px; "><h4 class="bfuh4"><span>NUESTRO EVENTOS</span></h4></p>
      <p class="bfuquote">Tu asistencia es importante para nosotros visitanos en los eventos qu estamos realizando.</p>
      <div class="imagecollection">
        <?php
      foreach($result as $row)
        {
          $product_description = $row->Product_Description;
          $product_price = $row->Product_Price;
          // echo $email;
        echo "<div class='bfufirstimage'>";
        echo "<div class='newdiv'>";
        echo  "<p>New</p>";
        echo    "</div>";
        echo  "<a href = ".base_url('buyfromus/view2/'.$product_description.'/'.$product_price.'/'.$email)."><img src=".base_url()."assets/imagenes/minibaner4.jpg alt='minibaner4'> </a>";
        // echo "<a href='index.php?choice=search&cat=".urlencode($cat)."&subcat=".urlencode($subcat)."&srch=".urlencode($srch)."&page=".urlencode($next)."'> Next </a>";
        // echo base_url('buyfromus/view2/'.$product_description.'/'.$product_price.'/'.$email);
        echo "<p>".$row->Product_Description."</p>";
        echo "<p style='color:#FFdb58;'>$".$row->Product_Price."</p>";
        echo "</div>";
           }

            ?>

        <!-- <div class="bfufirstimage">
          <div class="newdiv">
            <p>New</p>
          </div>
          <a href = "BuyFromUs2.html"><img src="imagenes/minibaner1.jpg" alt="minibaner1"> </a>

        </div>
        <div class="bfufirstimage">
          <div class="newdiv">
            <p>New</p>
          </div>
          <a href = "BuyFromUs2.html"><img src="imagenes/minibaner2.jpg" alt="minibaner2"> </a>

        </div>
          <div class="bfufirstimage">
            <div class="newdiv">
              <p>New</p>
            </div>
          <a href = "BuyFromUs2.html">  <img src="imagenes/minibaner3.jpg" alt="minibaner3"> </a>

          </div> -->
        </div>
      </main>
      <div class="footer">

          <form class="subscribe" action="index.html" method="post">
            <fieldset>
              <label class="subscribelabel" for=""><strong><i class="fa fa-paper-plane-o"></i> &nbsp;Registrese para reciber un <br>boletin</strong></label>
              <input class="subscribetext" type="text" name="" value="" placeholder="Introduce tu correo electronico">
              <button class="subscribebutton" type="button" name="button">Suscribir</button>
            </fieldset>
          </form>
          <div class="footerbottom">
            <p class="pfooterbottom"><strong>LEAN EN LAS REDES SOCIALES</strong></p>
            <div class="sociallogos">
              <p class="tfiicons"><i class="fa fa-twitter"></i></p>
              <p class="tfiicons"><i class="fa fa-facebook"></i></p>
              <p class="tfiicons"><i class="fa fa-instagram"></i></p>
            </div>
          </div>

        </div>
      </div>
      </body>
      </html>
