<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="CSS/leanevent.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
  </head>
  <body id="body">
    <div id="wrapper">
    <div class="smalldiv">
      <p style=" font-weight: bold; font-size: 25px; margin-top: 5px; margin-bottom: 5px; ">Bienvenido</p>
      <hr>
      <p>Gracias por ser parte en nuestros evento.</p>
      <hr>
      <button class="button2" type="button" name="button">
        Close
      </button>
    </div>
  </div>
  </body>
</html>
