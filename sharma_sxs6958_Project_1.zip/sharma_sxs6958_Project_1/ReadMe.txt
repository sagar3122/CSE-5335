The understanding of the project and snapshots of the DB are in Project_Understanding_sxs6958.pdf

WDM_ER_relational.pdf contains the ER diagram and relational schema used to develop the database.

The three sql files are the sql commands for creating DB schema, dropping tables and inserting values in the tables(oracle syntax used).  